

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
            <div class="card">
              <div class="card-header card-header-rose card-header-icon">
                <div class="card-icon" style="background-image: url(<?php echo e(asset("img/icons").'/Gestion_Rol.png'); ?>);">
                  <i class="material-icons">f</i>
                </div>
                <h4 class="card-title"><?php echo e(__('Roles')); ?></h4>
              </div>
              <div class="card-body">
                  
                <div class="row d-none">
                  <div class="col-12 text-left">
                      <a id="exportXlsx" href="<?php echo e(route('role_xlsx')); ?>" class="btn btn-sm btn-rose"><?php echo e(__('Export xlsx')); ?></a>
                      <a id="exportCsv" href="<?php echo e(route('role_csv')); ?>" class="btn btn-sm btn-rose"><?php echo e(__('Export csv')); ?></a>
                      <a id="exportPdf" href="<?php echo e(route('rolePdf',['all'])); ?>" target='_blank' class="btn btn-sm btn-rose"><?php echo e(__('Export pdf')); ?></a>
                  </div>
                </div>

                <div class="row col-12">
                  <div class="col-lg-11 col-md-11 col-sm-11 col-xs-12 text-right"> 
                   <a href="<?php echo e(route('role.create')); ?>" class="btn-add"><img src="<?php echo e(asset("img/icons").'/Agregar.png'); ?>"></a>
                  </div>
                  <div class="col-lg-1 col-md-1 col-sm-1 col-xs-12 text-left">
                    <div class="dropdown">
                      <button title="Download Data" class="btn btn-ns" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <a href="<?php echo e(route('role.create')); ?>" class="btn-add"><img src="<?php echo e(asset("img/icons").'/Descargar.png'); ?>"></a>
                      </button>
                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">                            
                        <p class="dropdown-item" onclick="exportDataCsv();"><i class="fa fa-file-code-o" aria-hidden="true"></i>&nbsp; CSV</p>
                        <p class="dropdown-item" onclick="exportDataXlsx();"><i class="fa fa-file-excel-o" aria-hidden="true"></i>&nbsp; XLSX</p>
                        <p class="dropdown-item" onclick="exportDataPdf();"><i class="fa fa-file-pdf-o" aria-hidden="true"></i>&nbsp; PDF</p>
                      </div>
                    </div>
                  </div>
                </div>
      
                <div class="table-responsive">
                  <?php echo $__env->make('layouts.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <table id="datatables" class="table table-striped table-no-bordered table-hover" style="display:none">
                    <thead class="text-dark">
                      <th>
                          <?php echo e(__('Name')); ?>

                      </th>
                      <th>
                        <?php echo e(__('Description')); ?>

                      </th>
                      <th>
                        <?php echo e(__('Creation date')); ?>

                      </th>
                        <th class="text-right">
                          <?php echo e(__('Actions')); ?>

                        </th>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                           <a href="<?php echo e(URL::action('RoleController@show',$role->id)); ?>"><?php echo e($role->name); ?></a> 
                          </td>
                          <td>
                            <?php echo e($role->description); ?>

                          </td>
                          <td>
                            <?php echo e($role->created_at->format('Y-m-d')); ?>

                          </td>
                            <td class="td-actions text-right">
                              <?php echo $__env->make('roles.options.actions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
  $(document).ready(function() {
    $('#datatables').fadeIn(1100);
    $('#datatables').DataTable({
      "pagingType": "full_numbers",
      "lengthMenu": [
        [10, 25, 50, -1],
        [10, 25, 50, "All"]
      ],
      responsive: true,
      language: {
        search: "_INPUT_",
        searchPlaceholder: $('#SearchTable').val(),
        "lengthMenu": $('#showTable').val(),
              "info": $('#infoTable').val(),
              "infoEmpty": $('#emptyTable').val(),
              "zeroRecords": $('#emptyRecords').val(),
              "infoFiltered": $('#filterRecords').val(),
        "paginate": {
            "next":     $('#nextTable').val(),
            "previous": $('#previusTable').val(),
            "first":    $('#firstTable').val(),
            "last":     $('#lastTable').val()
        },
      },
      "columnDefs": [
        { "orderable": false, "targets": 3 },
      ],
    });
  });
  $(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
</script>
<script>
  function exportDataCsv(){
    document.getElementById('exportCsv').click()
  }

  function exportDataXlsx(){
    document.getElementById('exportXlsx').click()
  }
  function exportDataPdf(){
    document.getElementById('exportPdf').click()
  }
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'role-management', 'menuParent' => 'user', 'titlePage' => __('Role Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\water-project\CotizadorH2O\resources\views/roles/index.blade.php ENDPATH**/ ?>