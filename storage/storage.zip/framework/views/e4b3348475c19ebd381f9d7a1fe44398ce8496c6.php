
<style>
    .table thead tr.c-2 th {
        font-size: 0.9rem;
        background: #efefef!important;
        color: black;
        padding: 2px 4px!important;
        font-weight: bold;
    }

    .table thead tr.cc th {
        font-size: 0.9rem;
        background: #bacfda;
        color: black;
        padding: 12px 10px;
        font-weight: bold;
    }

    .c-table td, .c-table th{
        border: solid 1px lightgrey;
    }

    .c-table {
        text-align: center;
    }

    .max-error {
        border-bottom: solid 1px red;
        background: #fce4ec;
        transition: all ease 0.2s;
    }
</style>

<div class="row">
    <div class="col-8">
        <table class="table c-table">
            <thead>
                <tr class="cc">
                    <th>ID</th>
                    <th>Material</th>
                    <th>Unidad</th>
                    <th>Cantidad</th>
                    <th>Tipo de material</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $project_materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->materials->name); ?></td>
                        <td><?php echo e($item->materials->unit); ?></td>
                        <td><?php echo e($item->qty); ?></td>
                        <td><?php echo e($item->materials->type); ?></td>
                        <td><i data-toggle="tooltip" data-placement="top" title="Eliminar" class="fa fa-trash" aria-hidden="true" onclick="removeMaterial(<?php echo e($item->id); ?>)"></i></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<div class="row">
    <div class="col-12">
        <div class="row t-head d-flex justify-content-around" style="background: #bacfda;">
            <span>ID</span>
            <span>Material</span>
            <span>Unidad</span>
            <span>Cantidad</span>
            <span>Tipo de material</span>
        </div>
        <?php $__currentLoopData = $project_materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        
        
        <?php ($currentId = $item->id); ?>
        <?php $__currentLoopData = $item->materials->providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mProvider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="row mt-3 d-flex justify-content-around" style="    background: #fafafa; padding-top: 10px; padding-bottom: 10px;">
                <div style="cursor: pointer;    margin-top: -8px;" onclick="showTable(<?php echo e($item->id); ?>)"><?php echo e($item->id); ?> <div class="d-inline-block" style="transform: translateY(8px);"><i class="material-icons">arrow_drop_down</i></div></div>
                <div><?php echo e($item->materials->name); ?></div>
                <div><?php echo e($item->materials->unit); ?></div>
                <div><?php echo e($item->qty); ?></div>
                <div><?php echo e($item->materials->type); ?></div>
            </div>
            <div id="t-<?php echo e($item->id); ?>" style="display: none" class="mt-2 mb-4">

                <table class="table c-table">
                    <thead>
                        <tr class="cc c-2">
                            <th>Proveedor</th>
                            <th>Existencia</th>
                            <th>Costo Unitario</th>
                            <th style="width:8%;">Cantidad</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php ($total = 0); ?>

                        <?php $__currentLoopData = $materialProvider[$item->material_id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($mp->qty <= 0): ?>
                            <?php continue; ?>
                        <?php endif; ?>
                            <?php ($total += $mp->qty * $mp->unit_cost); ?>
                            <tr>
                                <td scope="row"><?php echo e($mp->provider->contact_name); ?></td>
                                <td><?php echo e($mp->qty); ?></td>
                                <td><?php echo e(Helper::formatMoney($mp->unit_cost)); ?></td>
                                <td><input max="<?php echo e($mp->qty); ?>" class="total-item-<?php echo e($currentId); ?> form-control data-material" data-id="<?php echo e($mp->provider->id); ?>" type="number" value="<?php echo e($mp->materialProvider ? $mp->materialProvider->qty : "0"); ?>"></td>
                                <td><?php echo e(Helper::formatMoney($mp->qty * $mp->unit_cost)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <script>
                            $('.total-item-<?php echo e($currentId); ?>').on('change keyup', () => {
                                total = parseFloat(0.00);
                                $('.total-item-<?php echo e($currentId); ?>').each(function() {
                                    total += parseFloat($(this).val());
                                    if(total > <?php echo e($item->qty); ?>) {
                                        console.log('Error');
                                        $('.total-item-<?php echo e($currentId); ?>').addClass('max-error')
                                    } else {
                                        $('.total-item-<?php echo e($currentId); ?>').removeClass('max-error')
                                    }
                                })

                            })
                        </script>
                    </tbody>
                </table>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-12">
        <button class="float-right d-block btn btn-primary">Guardar</button>
    </div>
</div>
<script>
    function showTable(id) {
        console.log($('#t-'+id).css('display') == 'block');
        if ($('#t-'+id).css('display') == 'block'){
            $('#t-'+id).hide();
            return;
        }
        $('#t-'+id).show();
    }
</script>
<style>
    .t-head {
        color: #32526f;
        font-size: 1.1em;
        font-weight: bold;
        padding: 6px;
    }
</style>

<script>
    function removeMaterial(id) {
        $.ajax({
        type: 'DELETE',
        url: '/materialformat/'+id,
        data: {
            "_token": "<?php echo e(csrf_token()); ?>"
        }
    }).done(function(data) {
        loadMaterials();
    });
    }

    var delayer;
    $('.data-material').on('change keyup', function() {
        id = $(this).attr('data-id');
        data = $(this).val();
        console.log(id);
        clearTimeout(delayer);
        delayer = setTimeout(function() {
            $.ajax({
                type: 'PUT',
                url: '/accesoryformat/'+id+'/'+projectId,
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "qty": data
                }
            }).done(function(data) {
                loadCosts();
            });
        }, 500);

    });
    $(function () {
        $('#total-material').html("<?php echo e(Helper::formatMoney($total)); ?>");
    });
</script>
<?php /**PATH C:\xampp\htdocs\water-project\resources\views/techformat/_materials.blade.php ENDPATH**/ ?>