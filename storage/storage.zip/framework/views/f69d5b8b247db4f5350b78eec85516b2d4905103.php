<footer class="footer">
  <div class="container-fluid">
    <div class="copyright ">
      &copy;
      <script>
        document.write(new Date().getFullYear())
      </script> IIASA, <?php echo e(__('All rights reserved. Developed by')); ?> ISINET
      </div>
  </div>
</footer><?php /**PATH C:\xampp\htdocs\water-project\CotizadorH2O\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>