<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<img src="<?php echo e(asset("email/logo-bf.png")); ?>" class="logo" alt="Cotizador Agua H2O Logo">
</a>
</td>
</tr>
<?php /**PATH C:\xampp\htdocs\water-project\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>