<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <form method="post" enctype="multipart/form-data" action="<?php echo e(route('costs.store')); ?>" autocomplete="off"
                    class="form-horizontal">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('post'); ?>
                    <input type="hidden" id='formType' value='formCreate'>

                    <div class="card ">
                        <div class="card-header card-header-rose card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">supervisor_account</i>
                            </div>
                            <h4 class="card-title">Mano de Obra</h4>
                        </div>
                        <br>
                        <div class="card-body">
                            <div class="container">
                                <div class="row">
                                    <div class="col-6">
                                        <label class="col-12" style="margin-bottom:-12px; font-weight:bold;"><?php echo e(__('Especialidad')); ?></label>
                                        <div class="col-sm-12">
                                            <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                                <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" id="input-name" type="text" value="<?php echo e(old('name')); ?>"  />
                                                <span id="errorNameUser" class="d-none"><?php echo app('translator')->get('The name field cannot be empty'); ?></span>
                                                <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <label class="col-12" style="margin-bottom:-12px; font-weight:bold;"><?php echo e(__('Costo Unitario')); ?></label>
                                        <div class="col-sm-12">
                                            <div class="form-group<?php echo e($errors->has('unit_cost') ? ' has-danger' : ''); ?>">
                                                <input class="form-control<?php echo e($errors->has('unit_cost') ? ' is-invalid' : ''); ?>" name="unit_cost" id="input-unit_cost" type="text" value="<?php echo e(old('unit_cost')); ?>"  />
                                                <span id="errorNameUser" class="d-none"><?php echo app('translator')->get('The name field cannot be empty'); ?></span>
                                                <?php echo $__env->make('alerts.feedback', ['field' => 'unit_cost'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer d-flex flex-row-reverse" style="justify-content: end;">
                            <p onclick="validationSave();" class="btn btn-primary"><?php echo e(__('Save')); ?></p>
                            <a href="<?php echo e(route('user.index')); ?>" class="btn-rose btn"><?php echo e(__('Cancelar')); ?></a>
                            <button id="saveUser" type="submit" class="btn btn-rose btn-round d-none"><?php echo e(__('Save')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        document.querySelectorAll('input').forEach( node => node.addEventListener('keypress', e => {
            if(e.keyCode == 13) {
                e.preventDefault();
            }
        }));
    });
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'costs', 'menuParent' => 'costs-parent', 'titlePage' => 'Centro de Costos'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\water-project\resources\views/costs/create.blade.php ENDPATH**/ ?>