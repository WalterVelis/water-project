


<?php $__env->startSection('content'); ?>
<div class="container" style="padding: -120px">
  <div class="row justify-content-center">
    <img src="<?php echo e(asset("material").'/img/licons/agua-logo-1.png'); ?>" width="15%">
  </div>

    <div class="row">
      <div class="col-md-9 ml-auto mr-auto mb-1 text-center">
        <h3 style="font-weight: bold"><?php echo e(__('app.welcome')); ?> </h3>
      </div>
    </div>    

    <div class="row">
      <div class="col-lg-4 col-md-6 col-sm-8 ml-auto mr-auto">
        <form class="form" id="formLogin" method="POST" action="<?php echo e(route('login')); ?>">
          <?php echo csrf_field(); ?>
          <input type="hidden" id="tokenLogin" value="<?php echo e(csrf_token()); ?>">

          <div class="card card-login card-hidden">
            
            <div class="card-body ">
              <br>
              <div class="d-flex justify-content-center">
                <h3 class="card-title" style="color: #0b6696"><?php echo e(__('Login')); ?></h3>
              </div>              
              <div id='loadingTime' class="loaderSpinnerLogin d-none"></div>
              <div id='dataLogin' class="">
              <span class="form-group  bmd-form-group email-error <?php echo e($errors->has('email') ? ' has-danger' : ''); ?>" >
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons" style="color:#212121">email</i>
                    </span>
                  </div>
                  <input type="email" class="form-control" id="exampleEmails" name="email" placeholder="<?php echo e(__('Email')); ?>..." value="<?php echo e(old('email')); ?>" required>
                  <?php echo $__env->make('alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              </span>
              <span class="form-group bmd-form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="material-icons" style="color:#212121">lock_outline</i>
                    </span>
                  </div>
                  <input type="password" class="form-control" id="examplePassword" name="password" placeholder="<?php echo e(__('Password')); ?>..." required>
                  <?php echo $__env->make('alerts.feedback', ['field' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              </span>
            </div>

              <div id="tokenDiv" class="input-group d-none">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                    <i class="material-icons" style="color:#212121">security</i>
                  </span>
                </div>
                <input autocomplete="off" type="text" class="form-control" id="input-token" name="toke-req" placeholder="<?php echo e(__('Token Confirmation')); ?>...">
                <input type="hidden" class="form-control" id="input-token-hidden" name="toke-req-hidden" value="">
                <input type="hidden" class="form-control" id="input-status-token" name="toke-status-token" value="">
              </div>              
              
              

              
            </div>
            <div id="divP1" class="card-footer justify-content-center">
              <p onclick="checkDoubleFactor();" class="btn btn-rose btn-lg btn-round"><?php echo e(__('Lets Go')); ?></p>
            </div>
            <div id="divP2" class="card-footer justify-content-center d-none">
              <p onclick="doubleFactorValidation();" class="btn btn-rose btn-lg btn-round"><?php echo e(__('Lets Go')); ?></p>
            </div>
            
          </div>
        </form>
        <div class="row">
          <div class="col-6">
              <?php if(Route::has('password.request')): ?>
                  <a href="<?php echo e(route('password.request')); ?>" class="text-light">
                      <small><?php echo e(__('Forgot password?')); ?></small>
                  </a>
              <?php endif; ?>
          </div>
          <h1 id='msjEmail' class="d-none"><?php echo app('translator')->get('The confirmation token was sent to the email'); ?></h1>
          <h1 id='msjEmailError' class="d-none"><?php echo app('translator')->get('A conflict occurred when sending the email.'); ?></h1>
          <h1 id='msjToken' class="d-none"><?php echo app('translator')->get('That confirmation token is not valid'); ?></h1>
          <h1 id='msjTokenGoogle' class="d-none"><?php echo app('translator')->get('Enter the code generated by the application'); ?></h1>          
          
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
  $(document).ready(function() {
    md.checkFullPageBackgroundImage();
    setTimeout(function() {
      // after 1000 ms we add the class animated to the login/register card
      $('.card').removeClass('card-hidden');
    }, 700);
  });
</script>

<script>
  // Capture the event "enter" 
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('input').forEach( node => node.addEventListener('keypress', e => {
      if(e.keyCode == 13 && !$("#divP1").hasClass("d-none")) {
        checkDoubleFactor(); //Function when divP1 is showing
      }
      if(e.keyCode == 13 && !$("#divP2").hasClass("d-none")) {
        doubleFactorValidation(); //Function when divP2 is showing
      }
    }))
  });
</script>






<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', [
  'class' => 'off-canvas-sidebar',
  'classPage' => 'login-page',
  'activePage' => 'login',
  'title' => __('Balassa Films'),
  'pageBackground' => asset("img").'/agua-fondo-3.png'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\water-project\CotizadorH2O\resources\views/auth/login.blade.php ENDPATH**/ ?>