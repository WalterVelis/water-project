

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-8">
        <?php if(auth()->user()->change_password == 1): ?>
            
        
        <div class="card">
        <div class="card-header card-header-icon card-header-rose">
            <div class="card-icon" style="background-image: url(<?php echo e(asset("img/icons").'/Editar_Perfil.png'); ?>);">
              <i class="material-icons">f</i>
            </div>
            <h4 class="card-title"><?php echo e(__('Edit Profile')); ?>

            </h4>
          </div>
          <div class="card-body text-center">
            <form method="post" enctype="multipart/form-data" action="<?php echo e(route('profile.update')); ?>" autocomplete="off" class="form-horizontal">
              <?php echo csrf_field(); ?>
              <?php echo method_field('put'); ?>

              <div class="row">
                <label class="col-sm-3 col-form-label"><?php echo e(__('Profile photo')); ?></label>
                <div class="col-sm-7">
                  <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                    <div class="fileinput-new thumbnail img-circle">
                      <?php if(auth()->user()->picture): ?>
                        <img src="<?php echo e(auth()->user()->profilePicture()); ?>" alt="...">
                      <?php else: ?>
                        <img src="<?php echo e(asset('material')); ?>/img/placeholder.jpg" alt="...">
                      <?php endif; ?>
                    </div>
                    <div class="fileinput-preview fileinput-exists thumbnail img-circle"></div>
                    <div>
                      <span class="btn btn-rose btn-file">
                        <span class="fileinput-new"><?php echo e(__('Select image')); ?></span>
                        <span class="fileinput-exists"><?php echo e(__('Change')); ?></span>
                        <input type="file" name="photo" id = "input-picture" />
                      </span>
                        <a href="#pablo" class="btn btn-danger fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> <?php echo e(__('Remove')); ?></a>
                    </div>
                    <?php echo $__env->make('alerts.feedback', ['field' => 'photo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                </div>
              </div>
              <div class="row">
                <label class="col-sm-3 col-form-label"><?php echo e(__('Name')); ?></label>
                <div class="col-sm-7">
                  <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                    <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" id="input-name" type="text" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name', auth()->user()->name)); ?>" aria-required="true"/>
                    <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                </div>
              </div>
              <div class="row">
                <label class="col-sm-3 col-form-label"><?php echo e(__('Email')); ?></label>
                <div class="col-sm-7">
                  <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                    <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="input-email" type="email" placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e(old('email', auth()->user()->email)); ?>"/>
                    <?php echo $__env->make('alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                </div>
              </div>
              <button type="submit" class="btn btn-rose btn-lg btn-round pull-right"><?php echo e(__('Update Profile')); ?></button>
              <div class="clearfix"></div>
            </form>
          </div>
        </div>

        <?php endif; ?>

        <div class="card">
          <div class="card-header card-header-icon card-header-rose">
            <div class="card-icon" style="background-image: url(<?php echo e(asset("img/icons").'/Cambiar_Password.png'); ?>);">
              <i class="material-icons">f</i>
            </div>
            <h4 class="card-title"><?php echo e(__('Change password')); ?></h4>
          </div>
          <div class="card-body text-center">
            <form method="post" action="<?php echo e(route('profile.password')); ?>" class="form-horizontal">
              <?php echo csrf_field(); ?>
              <?php echo method_field('put'); ?>

              <div class="row">
                <label class="col-sm-4 col-form-label" for="input-current-password"><?php echo e(__('Current Password')); ?></label>
                <div class="col-sm-6">
                  <div class="form-group<?php echo e($errors->has('old_password') ? ' has-danger' : ''); ?>">
                    <input class="form-control<?php echo e($errors->has('old_password') ? ' is-invalid' : ''); ?>" input type="password" name="old_password" id="input-current-password" placeholder="<?php echo e(__('Current Password')); ?>" value=""/>
                    <?php echo $__env->make('alerts.feedback', ['field' => 'old_password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                </div>
              </div>
              <div class="row">
                <label class="col-sm-4 col-form-label" for="input-password"><?php echo e(__('New Password')); ?></label>
                <div class="col-sm-6">
                  <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                    <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" id="input-password" type="password" placeholder="<?php echo e(__('New Password')); ?>" value=""/>
                    <?php echo $__env->make('alerts.feedback', ['field' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                </div>
              </div>
              <div class="row">
                <label class="col-sm-4 col-form-label" for="input-password-confirmation"><?php echo e(__('Confirm New Password')); ?></label>
                <div class="col-sm-6">
                  <div class="form-group">
                    <input class="form-control" name="password_confirmation" id="input-password-confirmation" type="password" placeholder="<?php echo e(__('Confirm New Password')); ?>" value=""/>
                  </div>
                </div>
              </div>
              <button type="submit" class="btn btn-rose btn-lg btn-round pull-right"><?php echo e(__('Change password')); ?></button>
              <div class="clearfix"></div>
            </form>
          </div>
        </div>
        
      </div>

      <?php if(!auth()->user()->change_password): ?>
      <div class="col-md-4" style="display: block; margin-right: auto; margin-left: auto">
          <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <i class="material-icons">close</i>
            </button>
            <span>
              <b><?php echo e(__('Alert')); ?> - </b><?php echo e(__('Password needs to be updated')); ?></span>
          </div>
      </div>
      <?php endif; ?>

      <?php if(auth()->user()->change_password == 1): ?>
      <div class="col-md-4">
        <div class="card card-profile">          
          <div class="card-body">
            <br><br><br>
            <div class="card-avatar">
              <img class="img" src="<?php echo e(auth()->user()->profilePicture()); ?>" />
          </div>
          <br><br>
          </div>
        </div>

        
        
      </div>
      <?php endif; ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'profile-edit', 'menuParent' => 'profile', 'titlePage' => __('User Profile')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\water-project\resources\views/profile/edit.blade.php ENDPATH**/ ?>