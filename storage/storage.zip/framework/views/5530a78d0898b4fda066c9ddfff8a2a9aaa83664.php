<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <form method="post" enctype="multipart/form-data" action="<?php echo e(route('assignment.update', $assignmentData->id)); ?>" autocomplete="off"
                    class="form-horizontal">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <input type="hidden" id='formType' value='formCreate'>

                    <div class="card ">
                        <div class="card-header card-header-rose card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">supervisor_account</i>
                            </div>
                            <h4 class="card-title">Gestión de Proyectos</h4>
                        </div>
                        <br>
                        <div class="card-body">
                            <div class="container">
                                <div class="row mt-2">
                                    <div class="mt-5 col-12 col-md-6">
                                        <span style="margin-bottom:-10px;font-weight:bold;"><?php echo e(__('Vendedor Titular')); ?></span>
                                        <div class="form-group<?php echo e($errors->has('vendor_assigned') ? ' has-danger' : ''); ?>">
                                            <select class="form-control" name="vendor_assigned" id="" required>
                                                <option value="">No asignado</option>
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e($assignmentData->vendor_assigned == $user->id ? "selected" : ""); ?> value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php echo $__env->make('alerts.feedback', ['field' => 'vendor_assigned'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="mt-5 col-12 col-md-6">
                                        <span style="margin-bottom:-10px;font-weight:bold;"><?php echo e(__('Estatus')); ?></span>
                                        <div class="form-group<?php echo e($errors->has('status') ? ' has-danger' : ''); ?>">
                                            <select class="form-control" name="status" id="" required>
                                                <option <?php echo e($assignmentData->status == 4 ? "selected" : ""); ?> value="4">Cotizado</option>
                                                <option <?php echo e($assignmentData->status == 5 ? "selected" : ""); ?> value="5">Negociación</option>
                                                <option <?php echo e($assignmentData->status == 3 ? "selected" : ""); ?> value="3">Aceptado</option>
                                                <option <?php echo e($assignmentData->status == 2 ? "selected" : ""); ?> value="2">Rechazado</option>
                                                <option <?php echo e($assignmentData->status == 6 ? "selected" : ""); ?> value="6">Anticipo</option>
                                            </select>
                                            <?php echo $__env->make('alerts.feedback', ['field' => 'status'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                    <div class="mt-5 col-12 col-md-6">
                                        <span style="margin-bottom:-10px;font-weight:bold;"><?php echo e(__('Técnico asignado')); ?></span>
                                        <div class="form-group<?php echo e($errors->has('tech_assigned') ? ' has-danger' : ''); ?>">
                                            <select class="form-control" name="tech_assigned" id="" required>
                                                <option value="">No asignado</option>
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e($assignmentData->tech_assigned == $user->id ? "selected" : ""); ?> value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php echo $__env->make('alerts.feedback', ['field' => 'tech_assigned'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                    <div class="mt-5 col-12 col-md-7">
                                        <span style="margin-bottom:-10px;font-weight:bold;"><?php echo e(__('Administrador')); ?></span>
                                        <div class="form-group<?php echo e($errors->has('admin_assigned') ? ' has-danger' : ''); ?>">
                                            <select class="form-control" name="admin_assigned" id="" required>
                                                <option value="">No asignado</option>
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e($assignmentData->admin_assigned == $user->id ? "selected" : ""); ?> value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php echo $__env->make('alerts.feedback', ['field' => 'admin_assigned'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer d-flex flex-row-reverse" style="justify-content: end;">
                            
                            <button id="saveUser" type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        document.querySelectorAll('input').forEach( node => node.addEventListener('keypress', e => {
            if(e.keyCode == 13) {
                e.preventDefault();
            }
        }));
    });
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'project-managment', 'menuParent' => 'project-managment', 'titlePage' => 'Gestión de Proyectos'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\water-project\resources\views/assignment/edit.blade.php ENDPATH**/ ?>