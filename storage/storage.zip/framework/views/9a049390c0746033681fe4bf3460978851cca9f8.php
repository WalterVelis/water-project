<style>
    .form-check .form-check-label {
        padding-right: 0px!important;
    }


    .c_label {
        /* font-size: 1.1em !important; */
        padding: 0 !important;
        margin-left: 0px !important;
        width: auto !important;
        margin-top: 30px;
    }

    #all-container {
        background: #7dabc375;
        padding: 30px;
    }

    #format-content {
        padding: 20px;
        border: solid 4px #32526f;
        border-radius: 6px;
        background: white;
        height: 60vh;
        overflow-y: scroll;
        overflow-x: hidden;
    }

    .nav-item.active {
        color: white;
        background: #32526f;
    }
</style>

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div id="all-container">
                    <h3 style="margin-top:-10px;">
                    </h3>
                    <nav class="navbar step-navbar navbar-expand-lg c-nav">
                        <div class="container">
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-bar navbar-kebab"></span>
                            <span class="navbar-toggler-bar navbar-kebab"></span>
                            <span class="navbar-toggler-bar navbar-kebab"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                                <ul class="navbar-nav" style="">
                                    <li class="nav-item <?php echo e($format->internal_status >= 0 ? "c-enabled" : ""); ?>">
                                        <a class="nav-link" href="<?php echo e($format->internal_status >= 0 ? route('projects.edit', $format) : "#"); ?>"><?php echo e(__('Needs Diagnosis')); ?></a>
                                    </li>
                                    <li class="nav-item  <?php echo e($format->internal_status >= 1 ? "c-enabled" : ""); ?>">
                                        <a class="nav-link" href="<?php echo e($format->internal_status >= 1 ? route('techformat.edit', $format) : "#"); ?>"><?php echo e(__('Technical Lift')); ?></a>
                                    </li>
                                    <li class="nav-item  <?php echo e($format->internal_status >= 2 ? "c-enabled" : ""); ?>">
                                        <a class="nav-link" href="<?php echo e($format->internal_status >= 2 ? "/quotation/$format->id/edit" : "#"); ?>"><?php echo e(__('Quotation')); ?></a>
                                    </li>
                                    <li class="nav-item active <?php echo e($format->internal_status >= 3 ? "c-enabled" : ""); ?>">
                                        <a class="nav-link" href="<?php echo e($format->internal_status >= 3 ? "/order/$format->id" : "#"); ?>"><?php echo e(__('Purchase Order')); ?></a>
                                    </li>
                                    <li class="nav-item <?php echo e($format->internal_status >= 4 ? "c-enabled" : ""); ?>">
                                        <a class="nav-link" href="<?php echo e($format->internal_status >= 4 ? "/assignment/$format->id" : "#"); ?>"><?php echo e(__('Assignment')); ?></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                    <div class="card-body">

                        <div class="row d-none">
                            <div class="col-12 text-left">
                                <a id="exportXlsx" href="<?php echo e(route('user_xlsx')); ?>"
                                    class="btn btn-sm btn-rose"><?php echo e(__('Export xlsx')); ?></a>
                                <a id="exportCsv" href="<?php echo e(route('user_csv')); ?>"
                                    class="btn btn-sm btn-rose"><?php echo e(__('Export csv')); ?></a>
                                <a id="exportPdf"
                                    href="<?php echo e(route('userPdf',['all'])); ?>"
                                    target='_blank'
                                    class="btn btn-sm btn-rose"><?php echo e(__('Export pdf')); ?></a>
                            </div>
                        </div>

                        <div class="row col-12">

                            <div class="col-lg-1 col-md-1 col-sm-1 col-xs-12 text-right">

                            </div>
                            <div class="col-lg-11 col-md-11 col-sm-11 col-xs-12 text-right">
                                <h4>TOTAL A PAGAR <br> <strong id="totalSum"></strong></h4>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <?php echo $__env->make('layouts.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            

                                <table id="datatables" class="table table-striped table-no-bordered table-hover"
                                    style="display:none">
                                    <thead class="text-primary">
                                        <th>
                                            <?php echo e(__('Orden')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Proveedor')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Total a pagar por proveedor')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Fecha de orden de compra')); ?>

                                        <th>
                                            <?php echo e(__('Actions')); ?>

                                        </th>
                                    </thead>
                                    <tbody>
                                        
                                        
                                        <?php ($totalSum = 0.00); ?>
                                        <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($loop->iteration); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->contact_name); ?>

                                            </td>
                                            <td>
                                                <?php echo e(Helper::formatMoney($totals[$item->id] * 1.13)); ?>

                                                <?php ($totalSum += $totals[$item->id] * 1.13); ?>
                                            </td>

                                            <td>
                                                <?php echo e($item->created_at); ?>

                                            </td>
                                            <td class="td-actions text-right">
                                                <a data-toggle="tooltip" data-placement="top" title="Descargar" href="/getorder/<?php echo e($item->id); ?>/<?php echo e($id); ?>/<?php echo e($loop->iteration); ?>"><i class="material-icons">arrow_downward</i></a>
                                                
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            
                                
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function () {

            $('#totalSum').html('<?php echo e(Helper::formatMoney($totalSum)); ?>');

            $('#datatables').fadeIn(1100);
            $('#datatables').DataTable({
                "pagingType": "full_numbers",
                "lengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                responsive: true,
                // dom: 'Bfrtip',
                // buttons: [
                //     'copy', 'excel', 'pdf'
                // ],
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: $('#SearchTable').val(),
                    "lengthMenu": $('#showTable').val(),
                    "info": $('#infoTable').val(),
                    "infoEmpty": $('#emptyTable').val(),
                    "zeroRecords": $('#emptyRecords').val(),
                    "infoFiltered": $('#filterRecords').val(),
                    "paginate": {
                        "next": $('#nextTable').val(),
                        "previous": $('#previusTable').val(),
                        "first": $('#firstTable').val(),
                        "last": $('#lastTable').val()
                    },
                },
                "columnDefs": [{
                    "orderable": false,
                    "targets": 4
                }, ],
            });
        });

    </script>
    <script>
        function exportDataCsv() {
            document.getElementById('exportCsv').click()
        }

        function exportDataXlsx() {
            document.getElementById('exportXlsx').click()
        }

        function exportDataPdf() {
            document.getElementById('exportPdf').click()
        }

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'projects-management', 'menuParent' => 'projects', 'sublevel' => 'necesidades', 'titlePage' => __('Gestión de proyectos')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\water-project\resources\views/orders/index.blade.php ENDPATH**/ ?>