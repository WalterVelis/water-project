<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
    <div class="container-fluid">
      <div class="navbar-wrapper">
        <div class="navbar-minimize">
          <button id="minimizeSidebar" class="btn btn-just-icon btn-white btn-fab btn-round">
            <i class="material-icons text_align-center visible-on-sidebar-regular">more_vert</i>
            <i class="material-icons design_bullet-list-67 visible-on-sidebar-mini">view_list</i>
          </button>
        </div>
        <a class="navbar-brand" href="#"><?php echo e($titlePage); ?></a>
      </div>
      <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
        <span class="sr-only">Toggle navigation</span>
        <span class="navbar-toggler-icon icon-bar"></span>
        <span class="navbar-toggler-icon icon-bar"></span>
        <span class="navbar-toggler-icon icon-bar"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a class="nav-link" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <button class="btn btn-primary btn-round btn-fab btn-topbar"><i class="material-icons">notifications</i></button>
              <?php
              $notificacions=App\Notification::countNotificationActive();
              ?>
              <?php $__currentLoopData = $notificacions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($item->notifications == 0): ?>
              <?php else: ?>
              <span class="notification"><?php echo e($item->notifications); ?></span>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <p class="d-lg-none d-md-block">
                <?php echo e(__('Notifications')); ?>

              </p>
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
              <?php
              $notificacionsInfo=App\Notification::textNotificationActive();
              ?>
              <?php if(count($notificacionsInfo) == 0): ?>
              <a class="dropdown-item disabled" href="#"><?php echo e(__("You don't have any system notifications")); ?></a>
              <?php else: ?>
              <?php $__currentLoopData = $notificacionsInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                  $textOnclick = '';
              ?>
              <?php if($item->action == 'Approve Vendor'): ?>
                  <?php
                  $textOnclick = 'onclick=createVariableFilter();';
                  ?>
              <?php endif; ?>
              <a class="dropdown-item" <?php echo e($textOnclick); ?> href="<?php echo e($item->action_url); ?>"><?php echo app('translator')->get($item->description); ?> &nbsp;&nbsp;&nbsp;<span class="notification"><?php echo e($item->total); ?></span></a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </div>
          </li>
          <li class="nav-item dropdown">
              <a class="nav-link" href=""  onclick="urlCurrent();" >
                <button class="btn btn-primary btn-round btn-fab btn-topbar">
                <i class="material-icons">feedback</i></button>
              <p class="d-lg-none d-md-block">
                  <?php echo e(__('Help')); ?>

              </p>
            </a>
            <a  id="urlHelp" class="btn btn-primary d-none" target="_blank">help</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link" href="#" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <button class="btn btn-primary btn-round btn-fab btn-topbar">
              <i class="material-icons">person</i></button>
              <p class="d-lg-none d-md-block">
                  <?php echo e(__('Account')); ?>

              </p>
            </a>
            <div class="dropdown-menu dropdown-menu-right viewConnection" aria-labelledby="navbarDropdownProfile">
                <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>"><?php echo e(__('Profile')); ?></a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item logButton" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><?php echo e(__('Log out')); ?></a>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- End Navbar -->
<?php /**PATH C:\xampp\htdocs\water-project\resources\views/layouts/navbars/navs/auth.blade.php ENDPATH**/ ?>