<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <form method="post" enctype="multipart/form-data" action="<?php echo e(route('providers.store')); ?>" autocomplete="off"
                    class="form-horizontal">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('post'); ?>
                    <input type="hidden" id='formType' value='formCreate'>

                    <div class="card ">
                        <div class="card-header card-header-rose card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">supervisor_account</i>
                            </div>
                            <h4 class="card-title">Agregar Proveedor</h4>
                        </div>
                        <br>
                        <div class="card-body">
                            <div class="container">
                                <div class="row mt-2">
                                    <label class="col-12" style="margin-bottom:-12px; font-weight:bold;"><?php echo e(__('Razón social')); ?></label>
                                    <div class="col-sm-12">
                                        <div class="form-group<?php echo e($errors->has('denomination') ? ' has-danger' : ''); ?>">
                                            <input class="form-control<?php echo e($errors->has('denomination') ? ' is-invalid' : ''); ?>" name="denomination" id="input-denomination" type="text" value="<?php echo e(old('denomination')); ?>"  />
                                            <span id="errorNameUser" class="d-none"><?php echo app('translator')->get('The name field cannot be empty'); ?></span>
                                            <?php echo $__env->make('alerts.feedback', ['field' => 'denomination'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <label class="col-12" style="margin-bottom:-12px; font-weight:bold;"><?php echo e(__('Nombre del contacto')); ?></label>
                                    <div class="col-sm-12">
                                        <div class="form-group<?php echo e($errors->has('contact_name') ? ' has-danger' : ''); ?>">
                                            <input class="form-control<?php echo e($errors->has('contact_name') ? ' is-invalid' : ''); ?>" name="contact_name" id="input-contact_name" type="text" value="<?php echo e(old('contact_name')); ?>"  />
                                            <span id="errorNameUser" class="d-none"><?php echo app('translator')->get('The name field cannot be empty'); ?></span>
                                            <?php echo $__env->make('alerts.feedback', ['field' => 'contact_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <label class="col-12" style="margin-bottom:-12px; font-weight:bold;"><?php echo e(__('Cargo')); ?></label>
                                    <div class="col-sm-12">
                                        <div class="form-group<?php echo e($errors->has('job_title') ? ' has-danger' : ''); ?>">
                                            <input class="form-control<?php echo e($errors->has('job_title') ? ' is-invalid' : ''); ?>" name="job_title" id="input-job_title" type="text" value="<?php echo e(old('job_title')); ?>"  />
                                            <span id="errorNameUser" class="d-none"><?php echo app('translator')->get('The name field cannot be empty'); ?></span>
                                            <?php echo $__env->make('alerts.feedback', ['field' => 'job_title'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <label class="col-12" style="margin-bottom:-12px; font-weight:bold;"><?php echo e(__('Teléfono')); ?></label>
                                    <div class="col-sm-12">
                                        <div class="form-group<?php echo e($errors->has('phone') ? ' has-danger' : ''); ?>">
                                            <input class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" name="phone" id="input-phone" type="text" value="<?php echo e(old('phone')); ?>"  />
                                            <span id="errorNameUser" class="d-none"><?php echo app('translator')->get('The name field cannot be empty'); ?></span>
                                            <?php echo $__env->make('alerts.feedback', ['field' => 'phone'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <label class="col-12" style="margin-bottom:-12px; font-weight:bold;"><?php echo e(__('RFC')); ?></label>
                                    <div class="col-sm-12">
                                        <div class="form-group<?php echo e($errors->has('rfc') ? ' has-danger' : ''); ?>">
                                            <input class="form-control<?php echo e($errors->has('rfc') ? ' is-invalid' : ''); ?>" name="rfc" id="input-rfc" type="text" value="<?php echo e(old('rfc')); ?>"  />
                                            <span id="errorNameUser" class="d-none"><?php echo app('translator')->get('The name field cannot be empty'); ?></span>
                                            <?php echo $__env->make('alerts.feedback', ['field' => 'rfc'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <label class="col-12" style="margin-bottom:-12px; font-weight:bold;"><?php echo e(__('Dirección')); ?></label>
                                    <div class="col-sm-12">
                                        <div class="form-group<?php echo e($errors->has('direccion') ? ' has-danger' : ''); ?>">
                                            <input class="form-control<?php echo e($errors->has('direccion') ? ' is-invalid' : ''); ?>" name="direccion" id="input-direccion" type="text" value="<?php echo e(old('direccion')); ?>"  />
                                            <span id="errorNameUser" class="d-none"><?php echo app('translator')->get('The name field cannot be empty'); ?></span>
                                            <?php echo $__env->make('alerts.feedback', ['field' => 'direccion'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row mt-4">
                                    <label class="col-12" style="margin-bottom:-12px; font-weight:bold;"><?php echo e(__('Correo electrónico')); ?></label>
                                    <div class="col-sm-12">
                                        <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                                            <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="" type="email" value="<?php echo e(old('email')); ?>"  />
                                            <span id="errorNameUser" class="d-none"><?php echo app('translator')->get('The name field cannot be empty'); ?></span>
                                            <?php echo $__env->make('alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <label class="col-12" style="margin-bottom:-12px; font-weight:bold;"><?php echo e(__('Tipo de producto')); ?></label>
                                    <div class="col-sm-12 mb-5">
                                        <div class="form-group<?php echo e($errors->has('product_type') ? ' has-danger' : ''); ?>">
                                            <select class="form-control" name="product_type" id="product_type">
                                                <option value="0">Materiales extra</option>
                                                <option value="1">Accesorios Isla Urbana</option>
                                            </select>
                                            <span id="errorNameUser" class="d-none"><?php echo app('translator')->get('The name field cannot be empty'); ?></span>
                                            <?php echo $__env->make('alerts.feedback', ['field' => 'product_type'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="card-footer d-flex flex-row-reverse" style="justify-content: end;">
                            <p onclick="validationSave();" class="btn btn-primary"><?php echo e(__('Save')); ?></p>
                            <a href="<?php echo e(route('user.index')); ?>" class="btn-rose btn"><?php echo e(__('Cancelar')); ?></a>
                            <button id="saveUser" type="submit" class="btn btn-rose btn-round d-none"><?php echo e(__('Save')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        document.querySelectorAll('input').forEach( node => node.addEventListener('keypress', e => {
            if(e.keyCode == 13) {
                e.preventDefault();
            }
        }));
    });
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'provider', 'menuParent' => 'providers', 'titlePage' => 'Proveedores'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\water-project\resources\views/provider/create.blade.php ENDPATH**/ ?>