<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo e($name); ?></title>
    <style type="text/css">
        body {
            margin: 0px;
        }
        * {
            font-family: Verdana, Arial, sans-serif;
        }
        a {
            color: #fff;
            text-decoration: none;
        }
        table {
            font-size: x-small;
        }
        tfoot tr td {
            font-weight: bold;
            font-size: x-small;
        }
        .invoice table {
            margin: 15px;
        }
        .invoice h3 {
            margin-left: 15px;
        }
        .information {
            background-color: #ec407a;
            color: #FFF;
        }
        .information .logo {
            margin: 5px;
        }
        .information table {
            padding: 10px;
        }
    </style>
     <style>
       @page  { margin: 180px 0px; }
       #header { position: fixed; left: 0px; top: -180px; right: 0px; height: 100px; background-color: #ec407a; text-align: center; }
       #footer { position: fixed; left: 0px; bottom: -180px; right: 0px; height: 50px; background-color: #ec407a; }
     </style>
<body>
     <div id="header">
        <div class="information">
            <table width="100%">
                <tr>
                    <td align="left" style="width: 20%;">
                        <img src="<?php echo e(public_path()); ?>/email/logo-bf.png" alt="Balassa Films" width="64" class="logo"/>
        
                    </td>
                    <td align="center">
                        <h1><?php echo e($name); ?></h1>                
                    </td>
                    <td align="right" style="width: 20%;">
                    </td>
                </tr>
        
            </table>
        </div>       
     </div>
     <div id="footer">
        <div class="information" style="position: absolute; bottom: 0;">
            <table width="100%">
                <tr>
                    <td align="left" style="width: 50%;">
                        &copy; IIASA, <?php echo e(__('All rights reserved. Developed by')); ?> ISINET
                    </td>
                    <td align="right" style="width: 50%;">
                    </td>
                </tr>
        
            </table>
        </div>
     </div>
     <div class="invoice" style="margin-left: 30px">    
        <table width="100%">
            <thead>
              <tr>
                <th align="left">
                  <?php echo e(__('Name')); ?>

              </th>
              <th align="left">
                <?php echo e(__('Email')); ?>

              </th>
              <th align="left">
                <?php echo e(__('Role')); ?>

              </th>
              <th align="left">
                <?php echo e(__('Creation date')); ?>

              </th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $query1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td align="left">
                      <?php echo e($user->name); ?>

                    </td>
                    <td align="left">
                      <?php echo e($user->email); ?>

                    </td>
                    <td align="left">
                      <?php echo e($user->role->name); ?>

                    </td>
                    <td align="left">
                      <?php echo e($user->created_at->format('Y-m-d')); ?>

                    </td>
                  </tr>
                               
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
    
        </table>
    </div>



    <?php if($idioma == "1"): ?>
    <script type="text/php">
      if ( isset($pdf) ) {
          $font = $fontMetrics->getFont("Lato", "regular");
          $pdf->page_text(530, 770, "Página: {PAGE_NUM} de {PAGE_COUNT}", $font, 10, array(255,255,255));
      }
    </script>  
    <?php else: ?>
    <script type="text/php">
      if ( isset($pdf) ) {
          $font = $fontMetrics->getFont("Lato", "regular");
          $pdf->page_text(530, 770, "Page: {PAGE_NUM} of {PAGE_COUNT}", $font, 10, array(255,255,255));
      }
    </script>
    <?php endif; ?>




</body>
</html><?php /**PATH C:\xampp\htdocs\water-project\resources\views/users/options/pdfAll.blade.php ENDPATH**/ ?>