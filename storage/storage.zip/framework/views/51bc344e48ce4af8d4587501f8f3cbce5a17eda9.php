
<form method="post" action="<?php echo e(route('role.destroy', $role)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>    
    
    <a rel="tooltip" class="btn btn-link" href="<?php echo e(route('role.edit', $role)); ?>" data-original-title="" title="">
        <i class="material-icons">edit</i>
        <div class="ripple-container"></div>
    </a>
    
    <?php if($role->users()->count()==0): ?>
        <button type="button" class="btn btn-link" data-original-title="" title="" onclick="
            return swal({
                text: '<?php echo e(__('Are you sure you want to delete this role?')); ?>',
                showCancelButton: true,
                confirmButtonText: '<?php echo e(__('Yes, Delete!')); ?>',
                cancelButtonText: '<?php echo e(__('No, ¡Cancel!')); ?>',
                confirmButtonClass: 'btn btn-info',
                cancelButtonClass: 'btn btn-danger',
                buttonsStyling: false
            }).then((result) => {
                if (result.value) {
                  submit();
                }
            });">
            <i class="material-icons">close</i>
            <div class="ripple-container"></div>
        </button>
        <?php else: ?>
        <button type="button" class="btn btn-link" data-original-title="" title="<?php echo e(__('This role cannot be deleted because there are users with this role')); ?>">
            <i class="material-icons">not_interested</i>
            <div class="ripple-container"></div>
        </button>
        <?php endif; ?>
</form>


<?php /**PATH C:\xampp\htdocs\water-project\resources\views/roles/options/actions.blade.php ENDPATH**/ ?>