<?php if( !$entities ): ?>
    <span><?php echo e(__('No records found...')); ?></span>
    <?php
        return;
    ?>
<?php endif; ?>
<table class="table format-table">
    <thead>
        <th scope="col"><?php echo e(__('Name')); ?></th>
        <th scope="col"><?php echo e(__('Email')); ?></th>
        <th scope="col"><?php echo e(__('Telephone')); ?></th>
        <th scope="col"><?php echo e(__('Job Position')); ?></th>
        <th scope="col"><?php echo e(__('Actions')); ?></th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $entities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <?php echo e($item->name); ?> </td>
                <td> <?php echo e($item->email); ?> </td>
                <td> <?php echo e($item->telephone); ?> </td>
                <td> <?php echo e($item->position); ?> </td>
                <td> <i data-toggle="tooltip" data-placement="top" title="Eliminar" onclick="removePerson(<?php echo e($item->id); ?>)" class="fa fa-trash" aria-hidden="true"></i> </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<style>

    .format-table td{
        font-size: 1em!important;
    }

    .format-table th{
        font-size: 1.1em!important;
    }

    .format-table thead th {
        font-weight: bold!important;
    }
    .format-table th, .format-table td {
        padding: 12px 8px!important;
    }
</style>
<?php /**PATH C:\xampp\htdocs\water-project\resources\views/layouts/project-table.blade.php ENDPATH**/ ?>