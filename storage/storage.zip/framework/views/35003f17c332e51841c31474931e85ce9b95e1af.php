<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-rose card-header-icon">
                        <div class="card-icon">
                            <i class="material-icons">assignment</i>
                        </div>
                        <h4 class="card-title">
                            <?php echo e(__('Lista de Proyectos')); ?></h4>
                    </div>
                    <div class="card-body">

                        <div class="row d-none">
                            <div class="col-12 text-left">
                                <a id="exportXlsx" href="<?php echo e(route('user_xlsx')); ?>"
                                    class="btn btn-sm btn-rose"><?php echo e(__('Export xlsx')); ?></a>
                                <a id="exportCsv" href="<?php echo e(route('user_csv')); ?>"
                                    class="btn btn-sm btn-rose"><?php echo e(__('Export csv')); ?></a>
                                <a id="exportPdf"
                                    href="<?php echo e(route('userPdf',['all'])); ?>"
                                    target='_blank'
                                    class="btn btn-sm btn-rose"><?php echo e(__('Export pdf')); ?></a>
                            </div>
                        </div>

                        <div class="row col-12">
                            <div class="col-lg-11 col-md-11 col-sm-11 col-xs-12 text-right">
                                <a name="" id="" class="btn btn-primary btn-sm btn-round" style="color:white; padding:5px;" href="<?php echo e(route('projects.create')); ?>" role="button"><i style="color:white;font-size: 1em;padding: 4px;" class="fa fa-plus fw" aria-hidden="true"></i></a>
                                <?php if(App\User::hasPermissions("Budget Create Account")): ?>
                                    <a href="<?php echo e(route('projects.create')); ?>"
                                        class="btn btn-sm btn-rose"><?php echo e(__('Nuevo Proyecto')); ?></a>
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-1 col-md-1 col-sm-1 col-xs-12 text-right">
                                <div class="dropdown">
                                    <button title="Download Data" class="dropdown-toggle" style="background: none; border: none; font-size: 1.5em; margin-top: 6px;"
                                        type="button" id="dropdownMenuButton" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                        <i class="fa fa-download" aria-hidden="true"></i>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <p class="dropdown-item" onclick="exportDataCsv();"><i class="fa fa-file-code-o"
                                                aria-hidden="true"></i>&nbsp; CSV</p>
                                        <p class="dropdown-item" onclick="exportDataXlsx();"><i
                                                class="fa fa-file-excel-o" aria-hidden="true"></i>&nbsp; XLSX</p>
                                        <p class="dropdown-item" onclick="exportDataPdf();"><i class="fa fa-file-pdf-o"
                                                aria-hidden="true"></i>&nbsp; PDF</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <?php echo $__env->make('layouts.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php if( ! $projects->isEmpty() ): ?>

                                <table id="datatables" class="table table-striped table-no-bordered table-hover"
                                    style="display:none">
                                    <thead class="text-primary">
                                        <th>
                                            <?php echo e(__('Page')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Client')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Main Contact')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Place')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('First Contact')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Email')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Phone')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Quotation Date')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Estado')); ?>

                                        </th>
                                        <th>
                                            <?php echo e(__('Actions')); ?>

                                        </th>
                                    </thead>
                                    <tbody>

                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr <?php echo e($item->status == 0 ? 'style=opacity:0.5' : ''); ?>>
                                            <td>
                                                <?php echo e($item->page); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->client); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->main_contact); ?>

                                            </td>

                                            <td>
                                                <?php echo e($item->state); ?>, <?php echo e($item->municipality); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->date); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->email); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->phone); ?>

                                            </td>

                                            <td>
                                                <?php echo e($item->created_at); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->statusLabel()); ?>

                                            </td>
                                            <td class="td-actions text-right">
                                                <!-- <a href="<?php echo e(route('projects.show', $item->id)); ?>"><i class="material-icons">remove_red_eye</i></a> -->
                                                <a data-toggle="tooltip" data-placement="top" title="Editar" href="<?php echo e(route('projects.edit', $item->id)); ?>"><i class="material-icons">edit</i></a>
                                                
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            <?php else: ?>
                                <?php echo e(__('No records found')); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function () {
            $('#datatables').fadeIn(1100);
            $('#datatables').DataTable({
                "pagingType": "full_numbers",
                "lengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                responsive: true,
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'excel', 'pdf'
                ],
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: $('#SearchTable').val(),
                    "lengthMenu": $('#showTable').val(),
                    "info": $('#infoTable').val(),
                    "infoEmpty": $('#emptyTable').val(),
                    "zeroRecords": $('#emptyRecords').val(),
                    "infoFiltered": $('#filterRecords').val(),
                    "paginate": {
                        "next": $('#nextTable').val(),
                        "previous": $('#previusTable').val(),
                        "first": $('#firstTable').val(),
                        "last": $('#lastTable').val()
                    },
                },
                "columnDefs": [{
                    "orderable": false,
                    "targets": 4
                }, ],
            });
        });

    </script>
    <script>
        function exportDataCsv() {
            document.getElementById('exportCsv').click()
        }

        function exportDataXlsx() {
            document.getElementById('exportXlsx').click()
        }

        function exportDataPdf() {
            document.getElementById('exportPdf').click()
        }

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'projects-management', 'menuParent' => 'projects', 'sublevel' => 'necesidades', 'titlePage' => __('Gestión de Proyectos')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\water-project\resources\views/projects/index.blade.php ENDPATH**/ ?>