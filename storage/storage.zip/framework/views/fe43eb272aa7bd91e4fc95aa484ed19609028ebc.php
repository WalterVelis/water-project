<?php
    if(!isset($sublevel)){
      $sublevel="";
    }
?>
<?php if(auth()->user()->role->name == 'Vendor'): ?>
<li class="nav-item<?php echo e($activePage == 'vendor-management' ? ' active' : ''); ?>">
  <a class="nav-link" href="<?php echo e(URL::action('VendorController@edit', auth()->user()->vendor->id)); ?>">
    <div class="photo2 sidebar-image">
      <img src="<?php echo e(asset("img/icons").'/Gestion_proveedor.png'); ?>" />
    </div>
      <p><?php echo e(__('Profile Vendor')); ?></p>
  </a>
</li>
    
<?php endif; ?>

<?php if(App\User::hasPermissions('Role Index') || App\User::hasPermissions('User Index')): ?>
<li class="nav-item <?php echo e(($menuParent == 'role') ? ' active' : ''); ?>">
  <a class="nav-link" data-toggle="collapse" href="#bfUser" <?php echo e(($menuParent == 'laravel' || $activePage == 'dashboard') ? ' aria-expanded="true"' : ''); ?>>
    <div class="photo2 sidebar-image">
      <img src="<?php echo e(asset("img/icons").'/Gestion_Usuario.png'); ?>" />
    </div>
    <p><?php echo e(__('User Management')); ?>

      <b class="caret"></b>
    </p>
  </a>
  <div class="collapse <?php echo e(($menuParent == 'user') ? ' show' : ''); ?>" id="bfUser">
    <ul class="nav">

      
      <?php if(App\User::hasPermissions('Role Index')): ?>
      <li class="nav-item<?php echo e($activePage == 'role-management' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('role.index')); ?>">
        <span class="sidebar-mini"><?php echo e(__('app.rm')); ?></span>
          <span class="sidebar-normal"> <?php echo e(__('Role Management')); ?> </span>
        </a>
      </li>
      <?php endif; ?>

      <li class="nav-item<?php echo e($activePage == 'user-management' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
        <span class="sidebar-mini"><?php echo e(__('app.um')); ?></span>
          <span class="sidebar-normal"> <?php echo e(__('User Management')); ?> </span>
        </a>
      </li>

    </ul>
  </div>
</li>
<?php endif; ?>

<?php if(App\User::hasPermissions("Vendor Index")): ?>
<li class="nav-item <?php echo e(($menuParent == 'vendor') ? ' active' : ''); ?>">
  <a class="nav-link" data-toggle="collapse" href="#bfVendor" <?php echo e(($menuParent == 'vendor') ? ' aria-expanded="true"' : ''); ?>>
    <div class="photo2 sidebar-image">
      <img src="<?php echo e(asset("img/icons").'/Gestion_proveedor.png'); ?>"/>
    </div>
    <p><?php echo e(__('Vendor Management')); ?>

      <b class="caret"></b>
    </p>
  </a>
  <div class="collapse <?php echo e(($menuParent == 'vendor') ? ' show' : ''); ?>" id="bfVendor">
    <ul class="nav">

      <li class="nav-item<?php echo e($activePage == 'vendor-management' ? ' active' : ''); ?>">
        <a class="nav-link" href="#">
        <span class="sidebar-mini"><?php echo e(__('app.v')); ?></span>
          <span class="sidebar-normal"> <?php echo e(__('Vendors')); ?> </span>
        </a>
      </li>

    </ul>
  </div>
</li>
<?php endif; ?>

<?php if(App\User::hasPermissions("Vendor Index")): ?>
<li class="nav-item <?php echo e(($menuParent == 'vendor') ? ' active' : ''); ?>">
  <a class="nav-link" data-toggle="collapse" href="#proyectos" <?php echo e(($menuParent == 'vendor') ? ' aria-expanded="true"' : ''); ?>>
    <div class="photo2 sidebar-image">
      <img src="<?php echo e(asset("img/icons").'/Catalogo.png'); ?>" />
    </div>
    <!-- <i class="material-icons">perm_identity</i> -->
    <p><?php echo e(__('Poyectos')); ?>

      <b class="caret"></b>
    </p>
  </a>
  <div class="collapse <?php echo e(($menuParent == 'vendor') ? ' show' : ''); ?>" id="proyectos">
    <ul class="nav">

      <li class="nav-item<?php echo e($activePage == 'vendor-management' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('projects.index')); ?>">
        <span class="sidebar-mini"><?php echo e(__('app.v')); ?></span>
          <span class="sidebar-normal"> <?php echo e(__('Diagnostico')); ?> </span>
        </a>
      </li>

    </ul>
  </div>
</li>
<?php endif; ?>
<!-- <img src="<?php echo e(asset("img/icons").'/Gestion_proveedor.png'); ?>" />
<img src="<?php echo e(asset("img/icons").'/Catalogo.png'); ?>" />
<img src="<?php echo e(asset("img/icons").'/Gestion_presupuesto.png'); ?>" />
<img src="<?php echo e(asset("img/icons").'/Gestion_presupuesto.png'); ?>" /> -->
<?php /**PATH C:\xampp\htdocs\water-project\CotizadorH2O\resources\views/layouts/navbars/menus/base.blade.php ENDPATH**/ ?>