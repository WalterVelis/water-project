<style>
    .table thead tr.cc th {
        font-size: 0.9rem;
        background: #bacfda;
        color: black;
        padding: 12px 10px;
        font-weight: bold;
    }

    .c-table td, .c-table th{
        border: solid 1px lightgrey;
    }

    .c-table {
        text-align: center;
    }
</style>
<div class="row">
    <div class="col-8">
        <table class="table c-table">
            <thead>
                <tr class="cc">
                    <th>Días</th>
                    <th>Especialidad</th>
                    <th>Costo Unitario</th>
                    <th>Total</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $project_costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($pc->day); ?></td>
                        <td><?php echo e($pc->costs->name); ?></td>
                        <td><?php echo e(Helper::formatMoney($pc->cost)); ?></td>
                        <td><?php echo e(Helper::formatMoney($pc->cost * $pc->day)); ?></td>
                        <td><i data-toggle="tooltip" data-placement="top" title="Eliminar" class="fa fa-trash" aria-hidden="true" onclick="removeCost(<?php echo e($pc->id); ?>)"></i></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<div class="row">
    <div class="col-8">
        <table class="table c-table">
            <thead>
                <tr class="cc">
                    <th>Días</th>
                    <th>Especialidad</th>
                    <th style="    width: 90px;">Costo Unitario</th>
                    <th>Total</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php ($total = 0); ?>
                <?php $__currentLoopData = $project_costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($total += ($pc->cost * $pc->day)); ?>
                    <tr>
                        <td scope="row"><?php echo e($pc->day); ?></td>
                        <td><?php echo e($pc->costs->name); ?></td>
                        <td><input class="form-control unit_cost" style="width: 70px;" data-id="<?php echo e($pc->id); ?>" type="number" name="unit_cost" value="<?php echo e($pc->cost); ?>"></td>
                        <td><?php echo e(Helper::formatMoney($pc->cost * $pc->day)); ?></td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    function removeCost(id) {
        $.ajax({
        type: 'DELETE',
        url: '/costformat/'+id,
        data: {
            "_token": "<?php echo e(csrf_token()); ?>"
        }
        }).done(function(data) {
            loadCosts();
        });
    }

    var delayer;
    var loading = false;
    $('.unit_cost').on('change keyup', function() {
        id = $(this).attr('data-id');
        cost = $(this).val();
        console.log(id);
        clearTimeout(delayer);
        if(loading)
            return;
        delayer = setTimeout(function() {
            $.ajax({
                type: 'PUT',
                url: '/costformat/'+id+'/'+projectId,
                beforeSend: function( xhr ) {
                    loading = true;
                },
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "cost": cost
                }
            })
            .done(function(data) {
                loadCosts();
                loading = false;
            });
        }, 500);
    });

$(function () {
    $('#total-cost').html("<?php echo e(Helper::formatMoney($total)); ?>");
});
</script>
<?php /**PATH C:\xampp\htdocs\water-project\resources\views/techformat/_costs.blade.php ENDPATH**/ ?>