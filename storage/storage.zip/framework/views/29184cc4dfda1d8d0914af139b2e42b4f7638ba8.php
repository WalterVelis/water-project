<?php if($errors->has($field)): ?>
  <span id="<?php echo e($field); ?>-error" class="error text-danger" for="input-<?php echo e($field); ?>" style="display: block;"><?php echo e(ucfirst($errors->first($field))); ?></span>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\water-project\CotizadorH2O\resources\views/alerts/feedback.blade.php ENDPATH**/ ?>