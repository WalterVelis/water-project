<select class="form-control" name="municipality">
    <option readonly selected><?php echo e(__('Choose...')); ?></option>
    <?php $__currentLoopData = $municipality; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($item->municipio->municipio); ?>"> <?php echo e($item->municipio->municipio); ?> </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php /**PATH C:\xampp\htdocs\water-project\resources\views/layouts/_country/municipality.blade.php ENDPATH**/ ?>