<input type="hidden" id="showTable" value="<?php echo e(__('app.showtable')); ?>">
<input type="hidden" id="infoTable" value="<?php echo e(__('app.infotable')); ?>">
<input type="hidden" id="emptyTable" value="<?php echo e(__('app.emptytable')); ?>">
<input type="hidden" id="SearchTable" value="<?php echo e(__('Search')); ?>">
<input type="hidden" id="nextTable" value="<?php echo e(__('Next')); ?>">
<input type="hidden" id="previusTable" value="<?php echo e(__('Prev')); ?>">
<input type="hidden" id="firstTable" value="<?php echo e(__('First')); ?>">
<input type="hidden" id="lastTable" value="<?php echo e(__('Last')); ?>">
<input type="hidden" id="emptyRecords" value="<?php echo e(__('app.emptyrecord')); ?>">
<input type="hidden" id="filterRecords" value="<?php echo e(__('app.filterrecord')); ?>">

<?php /**PATH C:\xampp\htdocs\water-project\resources\views/layouts/table.blade.php ENDPATH**/ ?>