<div class="sidebar viewConnection" style="background-color: #51809b" data-color="rose" data-background-color="black">
  <!-- colores de fondo: 1- #32526f 2- #51809b 3- #7dabc3 4- #c9dbe7
    Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

    Tip 2: you can also add an image using data-image tag
-->
  <div class="logo">
    
    <center>
      <a href="/" class="simple-text logo-normal">
        <img src="<?php echo e(asset('material/img/licons/agua-logo-1.png')); ?>" width="75%"/>
      </a>
    </center>
  </div>
  <div class="sidebar-wrapper" style="height: 60%">
    <div class="user">
      <div class="photo">
        <img src="<?php echo e(auth()->user()->profilePicture()); ?>" />
      </div>
      <div class="user-info">
        <a data-toggle="collapse" href="#collapseProfile"   class="username">
          <span>
            <?php echo e(auth()->user()->name); ?>

            <b class="caret"></b>
          </span>
        </a>
        <div class="collapse<?php echo e($menuParent == 'profile' ? 'aria-expanded=true' : ''); ?>" id="collapseProfile">
          <ul class="nav">
            <li class="nav-item <?php echo e($activePage == 'profile-edit' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
                <span class="sidebar-mini">MP</span>
                <span class="sidebar-normal"> <?php echo e(__('My Profile')); ?> </span>
              </a>
            </li>
            <li class="nav-item <?php echo e($activePage == 'profile-security' ? ' active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(URL::action('ProfileController@viewDoubleFactorAuth', 'form')); ?>">
                <span class="sidebar-mini"><?php echo e(__('app.SC')); ?></span>
                <span class="sidebar-normal"> <?php echo e(__('Security Configuration')); ?> </span>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <ul class="nav" >
      <?php echo $__env->make('layouts.navbars.menus.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </ul>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\water-project\CotizadorH2O\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>