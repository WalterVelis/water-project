

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
            <form method="post" action="<?php echo e(route('projects.update', $project->id)); ?>" autocomplete="off" class="form-horizontal">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>

                <div class="card ">
                <div class="card-header card-header-rose card-header-icon">
                    <div class="card-icon">
                    <i class="material-icons">assignment</i>
                    </div>
                    <h4 class="card-title"><?php echo e(__('General data')); ?></h4>
                </div>

                <div class="card-body ">
                    <div class="row">
                    <div class="col-md-12 text-right">
                        <a href="<?php echo e(route('projects.index')); ?>" class="btn btn-sm btn-rose"><?php echo e(__('Back to list')); ?></a>
                    </div>
                    </div>
                <!-- Inicio -->

                    <div class="row col-12">
                        <div class="row col-6">
                            <label class="col-sm-2 col-form-label"><?php echo e(__('Name')); ?></label>
                            <div class="col-sm-9">
                                <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                    <input class="form-control" id="name" name="name" type="text"value="<?php echo e($project->name); ?>" />
                                    <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row col-6">
                            <label class="col-sm-2 col-form-label"><?php echo e(__('Description')); ?></label>
                            <div class="col-sm-9">
                                <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                    <input class="form-control" id="name" name="description" type="text"value="<?php echo e($project->description); ?>" />
                                    <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>

                    <!-- Fin -->

                </div>
                </div>

                <input name="" id="" class="btn btn-rose" type="submit" value="<?php echo e(__('Save')); ?>">

            </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<script>
$("#budAccount").select2({
  language: {
          noResults: function() {
              return "<?php echo e(__('No results found')); ?>";
          },
          searching: function() {
            return "<?php echo e(__('Searching')); ?>...";
          }
      }
})

function nextCode(block,code){
  idBlock=$('#budAccount').find('option:selected').val();
  if(idBlock==block){
    $('#input-code').val(code);
  }else{
    var routeRequest = mainRoute + "budgetaccount/nextCode/" + idBlock;
    $.get(routeRequest, function (res) {
      $('#input-code').val(res);
    });
  }
}

</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'budgetaccount-management', 'menuParent' => 'catalog', 'sublevel' => 'budget', 'titlePage' => __('Budget Account Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\water-project\resources\views/projects/edit.blade.php ENDPATH**/ ?>