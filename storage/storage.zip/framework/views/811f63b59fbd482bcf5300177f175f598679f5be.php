<form method="post" action="<?php echo e(url("/changeUser/{$user->id}")); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('post'); ?>
        
    <?php if(App\User::hasPermissions("User Update")): ?>
    <a rel="tooltip" class="btn btn-link" href="<?php echo e(route('user.edit', $user)); ?>" data-original-title="" title="">
        <i class="material-icons">edit</i>
        <div class="ripple-container"></div>
    </a>
    <?php endif; ?>
    
    <?php if($user->id != auth()->id() && App\User::hasPermissions("User Deactivate")): ?>
    <a rel="tooltip" class="btn btn-link"  href="#" onclick="pressResetData(<?php echo e($user->id); ?>);">
        <i class="material-icons">email</i>
        <div class="ripple-container"></div>
    </a> 
        <button type="button" class="btn btn-link" data-original-title="" title="" onclick="
            return swal({
                text: '<?php echo e(__('Are you sure you want to delete this user?')); ?>',
                showCancelButton: true,
                confirmButtonText: '<?php echo e(__('Yes')); ?>',
                cancelButtonText: '<?php echo e(__('No, ¡Cancel!')); ?>',
                confirmButtonClass: 'btn btn-info',
                cancelButtonClass: 'btn btn-danger',
                buttonsStyling: false
            }).then((result) => {
                if (result.value) {
                  submit();
                }
            });">
            <i class="material-icons">close</i>
            <div class="ripple-container"></div>
        </button>
        <?php endif; ?>
</form>



<form class="d-none" method="post" action="<?php echo e(url("email2reset/{$user->id}")); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('post'); ?>
    <button id="btnResetData<?php echo e($user->id); ?>" type="button" class="btn btn-link" data-original-title="" title="" onclick="
    return swal({
        text: '<?php echo e(__('The information will be sent again and the security and password settings will be reset')); ?>',
        showCancelButton: true,
        confirmButtonText: '<?php echo e(__('Yes, Send!')); ?>',
        cancelButtonText: '<?php echo e(__('No, ¡Cancel!')); ?>',
        confirmButtonClass: 'btn btn-info',
        cancelButtonClass: 'btn btn-danger',
        buttonsStyling: false
    }).then((result) => {
        if (result.value) {
          submit();
        }
    });">
    <i class="material-icons">close</i>
    <div class="ripple-container"></div>
    </button>
    </form>


<?php /**PATH C:\xampp\htdocs\water-project\resources\views/users/options/inactive.blade.php ENDPATH**/ ?>