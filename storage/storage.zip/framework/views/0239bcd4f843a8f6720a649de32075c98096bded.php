<select class="state form-control" name="state">
    <option readonly selected><?php echo e(__('Choose...')); ?></option>
    <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($item->id); ?>"> <?php echo e($item->estado); ?> </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<script>
    $('.state').on('change', function () {

        id = $(this).val();
        $('#municipality').load('/municipality/'+id)

    });
</script>
<?php /**PATH C:\xampp\htdocs\water-project\resources\views/layouts/_country/state.blade.php ENDPATH**/ ?>