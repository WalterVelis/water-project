<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8">
          <form method="post" enctype="multipart/form-data" action="<?php echo e(route('user.store')); ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>
            <input type="hidden" id='formType' value='formCreate'>

            <div class="card ">
              <div class="card-header card-header-rose card-header-icon">
                <div class="card-icon">
                  <i class="material-icons">supervisor_account</i>
                </div>
                <h4 class="card-title"><?php echo e(__('Add User')); ?></h4>
              </div>
              <div class="card-body  text-center">
                <div class="row">
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Profile photo')); ?></label>
                  <div class="col-sm-7">
                    <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                      <div class="fileinput-new thumbnail img-circle">
                        <img src="<?php echo e(asset('material')); ?>/img/placeholder.jpg" alt="...">
                      </div>
                      <div class="fileinput-preview fileinput-exists thumbnail img-circle"></div>
                      <div>
                        <span class="btn btn-primary btn-file">
                          <span style="color:white!important;" class="fileinput-new"><?php echo e(__('Select image')); ?></span>
                          <span class="fileinput-exists"><?php echo e(__('Change')); ?></span>
                          <input type="file" name="photo" id = "input-picture" />
                        </span>
                          <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> <?php echo e(__('Remove')); ?></a>
                      </div>
                      <?php echo $__env->make('alerts.feedback', ['field' => 'photo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Name')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" id="input-name" type="text" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name')); ?>" required />
                      <span id="errorNameUser" class="d-none"><?php echo app('translator')->get('The name field cannot be empty'); ?></span>
                      <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Email')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                      <input onkeyup="emailUnique();" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="input-email" type="email" placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e(old('email')); ?>" required />
                      <span id="errorEmailU" class="d-none"><?php echo app('translator')->get('This email already exists'); ?></span>
                      <span id="errorEmailUserXX" class="d-none"><?php echo app('translator')->get('The email field cannot be empty'); ?></span>
                      <?php echo $__env->make('alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Role')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('role_id') ? ' has-danger' : ''); ?>">
                      <select onchange="roleDetection();" class="js-example-basic-single js-states form-control" style="width: 100%" id="role_input" name="role_id" data-style="select-with-transition" title="" data-size="100" required>
                        <option value=""><?php echo e(__('Choose a role')); ?></option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <span id="errorRoleUser" class="d-none"><?php echo app('translator')->get('The email field cannot be empty'); ?></span>
                      <?php echo $__env->make('alerts.feedback', ['field' => 'role_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                  </div>
                </div>


                <div id="vendorDiv" class="row d-none">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Vendor Type')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group form-check-inline">

                      <div class="form-check">
                        <label class="form-check-label">
                          <input class="form-check-input" id="radio1X" type="radio" name="is_external" value="0"><?php echo app('translator')->get('Internal Vendor'); ?>
                          <span class="circle">
                            <span class="check"></span>
                          </span>
                        </label>
                      </div>
                      <div class="form-check">
                        <label class="form-check-label">
                          <input class="form-check-input" id="radio2X" type="radio" name="is_external" value="1"><?php echo app('translator')->get('External Vendor'); ?>
                          <span class="circle">
                            <span class="check"></span>
                          </span>
                        </label>
                      </div>
                    </div>
                    <div class="row">

                      <span id="errorVendor" class="d-none"><?php echo app('translator')->get('You must select a vendor type'); ?></span>
                    </div>




                    </div>

                  </div>

                  <div class="row d-none">
                    <input type="text" id="rol-text" name="rol-text" value="">
                  </div>
                
              </div>
              <input type="hidden" name="change_password" value="0">
              <input type="hidden" name="created_by" value="<?php echo e(auth()->user()->id); ?>">
              <div class="card-footer d-flex flex-row-reverse" style="justify-content: end;">
                  <p onclick="validationSave();" class="btn btn-primary btn-lg"><?php echo e(__('Save')); ?></p>
                  <a href="<?php echo e(route('user.index')); ?>" class="btn-rose btn btn-lg"><?php echo e(__('Cancelar')); ?></a>
                <button id="saveUser" type="submit" class="btn btn-rose btn-round btn-lg d-none"><?php echo e(__('Save')); ?></button>

                <button id="saveUser2" type="button" class="d-none" data-original-title="" title="" onclick="
            return swal({
                title: '<?php echo e(__('Warning')); ?>',
                text: '<?php echo e(__('Creating a vendor user will send an email with instructions for filling up their vendor profile, are you sure you want to create a vendor user?')); ?>',
                type: 'warning',
                showCancelButton: true,
                confirmButtonText: '<?php echo e(__('Yes')); ?>',
                cancelButtonText: '<?php echo e(__('No, ¡Cancel!')); ?>',
                confirmButtonClass: 'btn btn-info',
                cancelButtonClass: 'btn btn-danger',
                buttonsStyling: false
            }).then((result) => {
                if (result.value) {
                  submit();
                }
            });">
            <?php echo e(__('Save')); ?>

        </button>



              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>

<script>
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('input').forEach( node => node.addEventListener('keypress', e => {
      if(e.keyCode == 13) {
        e.preventDefault();
      }
    }))
  });
</script>

<script>
  //role_input
  $("#role_input").select2({
      language: {
          noResults: function() {
              return "<?php echo e(__('No results found')); ?>";
          },
          searching: function() {
            return "<?php echo e(__('Searching')); ?>...";
          }
      },
      theme: "classic",
  })
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'user-management', 'menuParent' => 'user', 'titlePage' => __('User Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\water-project\resources\views/users/create.blade.php ENDPATH**/ ?>