<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div class="card ">
                    <div class="card-header card-header-rose card-header-icon">
                        <div class="card-icon">
                            <i class="material-icons">supervisor_account</i>
                        </div>
                        <h4 class="card-title"><?php echo e(__('Add Role')); ?></h4>
                    </div>
                    <div class="card-body ">

                        <form method="post" action="<?php echo e(route('role.store')); ?>" autocomplete="off"
                            class="form-horizontal">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                            <div class="row">
                                <label style="text-align:left;font-weight:500;font-size:1.2em;" class="ml-3 col-sm-12 col-form-label"><?php echo e(__('Name')); ?></label>
                                <div class="col-sm-12">
                                    <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                        <input onkeypress="return lettersOnlySpace(event)"
                                            class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"
                                            name="name" id="input-name" type="text" placeholder="<?php echo e(__('Name')); ?>"
                                            value="<?php echo e(old('name')); ?>" aria-required="true" />
                                        <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <span id="errorNameP" class="d-none"><?php echo app('translator')->get('Role name cannot be empty'); ?></span>
                                        <span id="errorNameU" class="d-none"><?php echo app('translator')->get('This name already exists'); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label style="text-align:left;font-weight:500;font-size:1.2em;" class="ml-3 col-sm-12 col-form-label"><?php echo e(__('Description')); ?></label>
                                <div class="col-sm-12">
                                    <div class="form-group<?php echo e($errors->has('description') ? ' has-danger' : ''); ?>">
                                        <textarea cols="30" rows="1"
                                            class="form-control<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>"
                                            name="description" id="input-description" type="text"
                                            placeholder="<?php echo e(__('Description')); ?>"
                                            aria-required="true"><?php echo e(old('description')); ?></textarea>
                                        <?php echo $__env->make('alerts.feedback', ['field' => 'description'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row d-none">
                                <label class="col-sm-2 col-form-label"><?php echo e(__('Permission Count')); ?></label>
                                <div class="col-sm-7">
                                    <div class="form-group">
                                        <input class="form-control" name="permissionCount" id="input-permissionCount"
                                            type="number" placeholder="0" value="<?php echo e(old('permissionCount')); ?>" />
                                    </div>
                                </div>
                            </div>
                            <h6 class="card-description" style="color: black; margin-top: 1rem"><?php echo app('translator')->get('Lista de permisos asignados'); ?></h6>
                            <div id="PerAM" class="row d-flex justify-content-center" style="height: 10rem;">
                                <small>
                                    <span class="tim-note"></span><?php echo app('translator')->get('Unassigned Permissions'); ?>
                                </small>
                            </div>
                            <div class="d-none" id="errorPermissions">
                                <span class="error text-danger"><?php echo app('translator')->get("Permission slip can't be empty"); ?></span>
                            </div>
                            <div class="row d-none" id="divTablePA">
                                <div class="table-responsive divRol" style="height: 10rem; overflow: auto;">
                                    <table class="table" id="tablePA">
                                        <thead class='text-dark'>
                                            <tr>
                                                <th><?php echo app('translator')->get('Permission Name'); ?></th>
                                                <th class="text-right"><?php echo app('translator')->get('Actions'); ?></th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                    </div>
                    <input type="hidden" name="created_by" value="<?php echo e(auth()->user()->id); ?>">
                    <div class="card-footer float-right" style="padding-top: 0px; justify-content: flex-end;">
                        <a href="<?php echo e(route('role.index')); ?>" class="btn btn-rose"><?php echo e(__('CANCEL')); ?></a>
                        <p class="btn btn-primary pull-right" onclick="PermissionDataValidation();">
                            <?php echo e(__('Save')); ?></p>
                    </div>
                    <div class="d-none">
                        <button id="permissionSave" type="submit"
                            class="btn btn-rose btn-round pull-right"><?php echo e(__('Save')); ?></button>
                    </div>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header card-header-rose card-header-icon">
                        <div class="card-icon">
                            <i class="material-icons">lock</i>
                        </div>
                        <h4 class="card-title"><?php echo e(__('Permission Filter')); ?></h4>
                    </div>
                    <div class="card-body ">

                        <div class="row">
                            <label class="col-sm-2 col-form-label"><?php echo app('translator')->get('Filter'); ?></label>
                            <div class="col-sm-10">
                                <div class="row">
                                    <div class="col-md-7">
                                        <div class="form-group">
                                            <input id="inputFP" onkeyup="filterPermissions();" type="text"
                                                class="form-control" placeholder="<?php echo e(__('Permission Name')); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="PerFM" class="d-none">
                            <h6>
                                <span class="tim-note"></span><?php echo app('translator')->get('Permission Not Found'); ?></h6>
                        </div>
                        <input id="header1" type="text" value="<?php echo e(__('Permission Name')); ?>" class="d-none" />
                        <input id="header2" type="text" value="<?php echo e(__('Actions')); ?>" class="d-none" />

                        <div class="table-responsive divRol" div="divTablePF" style="height: 21.7rem;">
                            <table class="table" id="tablePF">
                                <thead>
                                    <tr>
                                        <th><?php echo app('translator')->get('Permission Name'); ?></th>
                                        <th class="text-right"><?php echo app('translator')->get('Actions'); ?></th>
                                    </tr>
                                </thead>
                                <?php $__currentLoopData = $permissionAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr id='filterRow<?php echo e($loop->index); ?>' style='background-color: white'>
                                    <td id='filterColumn02-<?php echo e($loop->index); ?>'><?php echo e($permission->description); ?></td>
                                    <td id='filterColumn03-<?php echo e($loop->index); ?>' class='d-none'><?php echo e($permission->id); ?></td>
                                    <td class='td-actions text-right'>
                                        <button type='submit' value="<?php echo e($loop->index); ?>"
                                            onclick='addPermission("<?php echo e($loop->index); ?>");' class='btn btn-lg btn-link'>
                                            <i class='material-icons'>add_circle</i>
                                        </button>
                                    </td>
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>

<script>
    document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('input').forEach( node => node.addEventListener('keypress', e => {
      if(e.keyCode == 13) {
        e.preventDefault();
      }
    }))
  });
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'role-management', 'menuParent' => 'user', 'titlePage' => __('Role Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\water-project\resources\views/roles/create.blade.php ENDPATH**/ ?>